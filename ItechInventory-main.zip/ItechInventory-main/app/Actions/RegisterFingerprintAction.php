<?php

namespace App\Actions;

use Lorisleiva\Actions\Concerns\AsAction;

class RegisterFingerprintAction
{
    use AsAction;

    public function handle()
    {
        // ...
    }
}
