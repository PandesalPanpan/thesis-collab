<?php

namespace App\Livewire;

use Livewire\Component;

class RegisterFingerprint extends Component
{
    public function render()
    {
        return view('livewire.register-fingerprint');
    }
}
